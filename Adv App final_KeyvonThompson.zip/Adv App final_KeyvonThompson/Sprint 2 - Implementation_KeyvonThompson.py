#!/usr/bin/env python3

def process_sentence(sentence):
    """
    Converts a pseudo-English sentence describing coin quantities 
    into a dollar amount (as a string in X.YY format).
    This corrected version handles uppercase/mixed-case denominations.
    """
    coin_values = {
        "penny": 1,
        "pennies": 1,
        "nickel": 5,
        "nickels": 5,
        "dime": 10,
        "dimes": 10,
        "quarter": 25,
        "quarters": 25
    }
    
    tokens = sentence.strip().split()
    total_cents = 0
    index = 0

    while index < len(tokens):
        # 1) Read the quantity
        quantity_str = tokens[index]
        quantity = int(quantity_str)
        
        # 2) Read the denomination
        denomination_str = tokens[index + 1]
        
        # *** Change: make sure to lower() the denomination for the lookup
        denomination_str_lower = denomination_str.lower()
        
        # 3) Accumulate total
        total_cents += quantity * coin_values[denomination_str_lower]
        
        # Move to the next pair
        index += 2
        
        # Skip the word "and" if present
        if index < len(tokens) and tokens[index].lower() == "and":
            index += 1

    # Convert cents to dollars
    dollars = total_cents / 100.0
    return f"{dollars:.2f}"


def main():
    print("Enter coin phrases (leave empty to quit).")
    while True:
        line = input("> ").strip()
        if not line:
            break
        result = process_sentence(line)
        print(result)


if __name__ == "__main__":
    main()
