Python 3.12.1 (tags/v3.12.1:2305ca5, Dec  7 2023, 22:03:25) [MSC v.1937 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> #!/usr/bin/env python3
... """
... This script reads lines describing an amount of money in coins 
... and converts them to a dollar amount in X.YY format.
... """
... 
... def process_sentence(sentence):
...     # Dictionary mapping coin denominations to their value in cents
...     coin_values = {
...         "penny": 1,
...         "pennies": 1,
...         "nickel": 5,
...         "nickels": 5,
...         "dime": 10,
...         "dimes": 10,
...         "quarter": 25,
...         "quarters": 25
...     }
...     
...     # Split sentence into tokens
...     tokens = sentence.strip().split()
...     
...     total_cents = 0
...     index = 0
...     
...     # Loop through tokens in pairs: [quantity, denomination]
...     while index < len(tokens):
...         quantity_str = tokens[index]
...         denomination_str = tokens[index+1]
...         
...         quantity = int(quantity_str)  # convert to int
...         
...         # Add the correct coin value to total
...         total_cents += quantity * coin_values[denomination_str]
...         
...         # Advance by 2 tokens
...         index += 2
        
        # If there is an "and" word, skip it
        if index < len(tokens) and tokens[index].lower() == "and":
            index += 1
    
    # Convert cents to dollars
    dollars = total_cents / 100.0
    
    # Return as a string with 2 decimal places
    return f"{dollars:.2f}"


def main():
    # Example usage: read lines until empty or CTRL+D
    print("Enter coin phrases (leave empty to quit):")
    while True:
        line = input("> ").strip()
        if not line:
            break
        result = process_sentence(line)
        print(result)


if __name__ == "__main__":
    main()
